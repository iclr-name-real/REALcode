#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${REPO_ROOT}"

_CONFIG_KEYS=(
  PYTHON GRAPHAPD_MODE TARGET SEED DEVICE EPOCHS
  LR WEIGHT_DECAY LAMBDA_TRADEOFF MEMORY_GAMMA K NHID NUM_LAYERS GNN
  DROPOUT DROPOUT_RATIO MEMORY_INIT PRETRAIN_DIR
  APD_NUM_VIEWS APD_EDGE_DROP APD_EDGE_ADD APD_VIEW_POLICY
  APD_PROBE_INTERVAL APD_PROBE_TEMP APD_LAMBDA_PROBE APD_RNODE_MODE APD_M1_M2_COUPLING
  APD_WARMUP_EPOCHS APD_M2_RAMP_EPOCHS APD_CLEAN_FLOOR APD_LAMBDA_CLEAN
  APD_LAMBDA_NOISE APD_LAMBDA_SIM APD_SIM_VIEW_MODE APD_WRONG_UPDATE_INTERVAL APD_WRONG_SIGNAL APD_WRONG_MOMENTUM
  APD_WRONG_NORM APD_EXPERT_WRONG_SIGNAL APD_EXPERT_WRONG_MOMENTUM
  APD_RELIABILITY_MODE APD_GAP_FLOOR_MODE APD_GAP_FLOOR_MIX
  APD_SOURCE_PRUNE_MODE APD_SOURCE_PRUNE_FLOOR
  APD_BETA APD_ATA_FLOOR APD_GATE_SCORE_MODE APD_GATE_SOURCE_SHARPNESS APD_GATE_DIFFICULTY_WEIGHT APD_GATE_CONFIDENCE_WEIGHT APD_LAMBDA_ATA_ANCHOR
  APD_M3_START_EPOCH APD_LAMBDA_M3 APD_M3_SOURCE_TEMP APD_M3_ATA_TEMP
  APD_GATE_HIDDEN APD_LAMBDA_GATE_PRIOR APD_MEMORY_UPDATE_MODE APD_WRONG_EVENT_MODE
  APD_MEMORY_PROBE_WEIGHT APD_WRONG_PROBE_WEIGHT
  APD_ATA_MASS_TARGET APD_LAMBDA_ATA_MASS
  APD_EVAL_BLEND_MODE APD_EVAL_BLEND_GAMMA APD_EXTRA_ARGS LOG_DIR LOG_FILE RESULTS_PATH
)

load_config_defaults() {
  local config_file="$1"
  local key
  declare -A explicit_values
  declare -A explicit_set
  if [[ ! -f "${config_file}" ]]; then
    echo "CONFIG file not found: ${config_file}" >&2
    exit 2
  fi
  for key in "${_CONFIG_KEYS[@]}"; do
    if [[ -v "${key}" ]]; then
      explicit_set["${key}"]=1
      explicit_values["${key}"]="${!key}"
    fi
  done
  set -a
  source "${config_file}"
  set +a
  for key in "${_CONFIG_KEYS[@]}"; do
    if [[ -n "${explicit_set[${key}]+x}" ]]; then
      printf -v "${key}" '%s' "${explicit_values[${key}]}"
    fi
  done
}

if [[ -n "${CONFIG:-}" ]]; then
  load_config_defaults "${CONFIG}"
fi

PYTHON=${PYTHON:-python}

GRAPHAPD_MODE=${GRAPHAPD_MODE:-priorgate_ablation}
TARGET=${TARGET:-DBLPv7}
SEED=${SEED:-2080}
DEVICE=${DEVICE:-cuda:0}
EPOCHS=${EPOCHS:-2000}

LR=${LR:-0.001}
WEIGHT_DECAY=${WEIGHT_DECAY:-0.001}
LAMBDA_TRADEOFF=${LAMBDA_TRADEOFF:-0.2}
MEMORY_GAMMA=${MEMORY_GAMMA:-0.9}
K=${K:-40}
NHID=${NHID:-128}
NUM_LAYERS=${NUM_LAYERS:-2}
GNN=${GNN:-gcn}
DROPOUT_RATIO=${DROPOUT_RATIO:-${DROPOUT:-0.1}}
MEMORY_INIT=${MEMORY_INIT:-source_ensemble}
PRETRAIN_DIR=${PRETRAIN_DIR:-pretrain}
RESULTS_PATH=${RESULTS_PATH:-results.txt}

APD_NUM_VIEWS=${APD_NUM_VIEWS:-3}
APD_EDGE_DROP=${APD_EDGE_DROP:-0.05}
APD_EDGE_ADD=${APD_EDGE_ADD:-0.01}
APD_VIEW_POLICY=${APD_VIEW_POLICY:-alternate}
APD_PROBE_INTERVAL=${APD_PROBE_INTERVAL:-10}
APD_PROBE_TEMP=${APD_PROBE_TEMP:-1.0}
APD_LAMBDA_PROBE=${APD_LAMBDA_PROBE:-0.5}
APD_RNODE_MODE=${APD_RNODE_MODE:-max}
APD_M1_M2_COUPLING=${APD_M1_M2_COUPLING:-legacy}

APD_WARMUP_EPOCHS=${APD_WARMUP_EPOCHS:-10}
APD_M2_RAMP_EPOCHS=${APD_M2_RAMP_EPOCHS:-0}
APD_CLEAN_FLOOR=${APD_CLEAN_FLOOR:-0.0}
APD_LAMBDA_CLEAN=${APD_LAMBDA_CLEAN:-1.0}
APD_LAMBDA_NOISE=${APD_LAMBDA_NOISE:-0.05}
APD_LAMBDA_SIM=${APD_LAMBDA_SIM:-0}
APD_SIM_VIEW_MODE=${APD_SIM_VIEW_MODE:-first}
APD_WRONG_UPDATE_INTERVAL=${APD_WRONG_UPDATE_INTERVAL:-1}
APD_WRONG_SIGNAL=${APD_WRONG_SIGNAL:-confidence}
APD_WRONG_MOMENTUM=${APD_WRONG_MOMENTUM:-0.9}
APD_WRONG_NORM=${APD_WRONG_NORM:-robust}
APD_EXPERT_WRONG_SIGNAL=${APD_EXPERT_WRONG_SIGNAL:-confidence}
APD_EXPERT_WRONG_MOMENTUM=${APD_EXPERT_WRONG_MOMENTUM:-0.9}
APD_RELIABILITY_MODE=${APD_RELIABILITY_MODE:-legacy}
APD_GAP_FLOOR_MODE=${APD_GAP_FLOOR_MODE:-mix}
APD_GAP_FLOOR_MIX=${APD_GAP_FLOOR_MIX:-0.3}
APD_SOURCE_PRUNE_MODE=${APD_SOURCE_PRUNE_MODE:-none}
APD_SOURCE_PRUNE_FLOOR=${APD_SOURCE_PRUNE_FLOOR:-0.0}

APD_BETA=${APD_BETA:-0.5}
APD_ATA_FLOOR=${APD_ATA_FLOOR:-0.7}
APD_GATE_SCORE_MODE=${APD_GATE_SCORE_MODE:-legacy}
APD_GATE_SOURCE_SHARPNESS=${APD_GATE_SOURCE_SHARPNESS:-1.0}
APD_GATE_DIFFICULTY_WEIGHT=${APD_GATE_DIFFICULTY_WEIGHT:-1.0}
APD_GATE_CONFIDENCE_WEIGHT=${APD_GATE_CONFIDENCE_WEIGHT:-1.0}
APD_LAMBDA_ATA_ANCHOR=${APD_LAMBDA_ATA_ANCHOR:-0.2}
APD_M3_START_EPOCH=${APD_M3_START_EPOCH:-0}
APD_LAMBDA_M3=${APD_LAMBDA_M3:-1.0}
APD_M3_SOURCE_TEMP=${APD_M3_SOURCE_TEMP:-1.0}
APD_M3_ATA_TEMP=${APD_M3_ATA_TEMP:-1.0}
APD_GATE_HIDDEN=${APD_GATE_HIDDEN:-64}
APD_LAMBDA_GATE_PRIOR=${APD_LAMBDA_GATE_PRIOR:-0.10}
APD_MEMORY_UPDATE_MODE=${APD_MEMORY_UPDATE_MODE:-ata}
APD_WRONG_EVENT_MODE=${APD_WRONG_EVENT_MODE:-final}
APD_MEMORY_PROBE_WEIGHT=${APD_MEMORY_PROBE_WEIGHT:-0.50}
APD_WRONG_PROBE_WEIGHT=${APD_WRONG_PROBE_WEIGHT:-0.50}
APD_ATA_MASS_TARGET=${APD_ATA_MASS_TARGET:-0.50}
APD_LAMBDA_ATA_MASS=${APD_LAMBDA_ATA_MASS:-0.10}

APD_EVAL_BLEND_MODE=${APD_EVAL_BLEND_MODE:-none}
APD_EVAL_BLEND_GAMMA=${APD_EVAL_BLEND_GAMMA:-0.0}

APD_EXTRA_ARGS=${APD_EXTRA_ARGS:-}
LOG_DIR=${LOG_DIR:-runs/graphapd_${GRAPHAPD_MODE}}
mkdir -p "${LOG_DIR}"

if [[ "${GRAPHAPD_MODE}" != "baseline" && "${GRAPHAPD_MODE}" != "m1" && "${GRAPHAPD_MODE}" != "m1_m2" && "${GRAPHAPD_MODE}" != "priorgate_ablation" && "${GRAPHAPD_MODE}" != "priorgate_joint" && "${GRAPHAPD_MODE}" != "trainablegate_ablation" && "${GRAPHAPD_MODE}" != "full_joint" ]]; then
  echo "Unsupported GRAPHAPD_MODE=${GRAPHAPD_MODE}" >&2
  echo "Allowed: baseline, m1, m1_m2, priorgate_ablation, priorgate_joint, trainablegate_ablation, full_joint" >&2
  exit 2
fi

COMMON_ARGS=(
  --target "${TARGET}"
  --device "${DEVICE}"
  --epochs "${EPOCHS}"
  --seed "${SEED}"
  --lr "${LR}"
  --weight_decay "${WEIGHT_DECAY}"
  --lambda_tradeoff "${LAMBDA_TRADEOFF}"
  --memory_gamma "${MEMORY_GAMMA}"
  --K "${K}"
  --nhid "${NHID}"
  --num_layers "${NUM_LAYERS}"
  --gnn "${GNN}"
  --dropout_ratio "${DROPOUT_RATIO}"
  --memory_init "${MEMORY_INIT}"
  --results_path "${RESULTS_PATH}"
)

M1_ARGS=(
  --apd_m1
  --apd_num_views "${APD_NUM_VIEWS}"
  --apd_edge_drop "${APD_EDGE_DROP}"
  --apd_edge_add "${APD_EDGE_ADD}"
  --apd_view_policy "${APD_VIEW_POLICY}"
  --apd_probe_interval "${APD_PROBE_INTERVAL}"
  --apd_probe_temp "${APD_PROBE_TEMP}"
  --apd_lambda_probe "${APD_LAMBDA_PROBE}"
  --apd_rnode_mode "${APD_RNODE_MODE}"
  --apd_m1_m2_coupling "${APD_M1_M2_COUPLING}"
)

M2_ARGS=(
  --apd_m2
  --apd_warmup_epochs "${APD_WARMUP_EPOCHS}"
  --apd_m2_ramp_epochs "${APD_M2_RAMP_EPOCHS}"
  --apd_clean_floor "${APD_CLEAN_FLOOR}"
  --apd_lambda_clean "${APD_LAMBDA_CLEAN}"
  --apd_lambda_noise "${APD_LAMBDA_NOISE}"
  --apd_lambda_sim "${APD_LAMBDA_SIM}"
  --apd_sim_view_mode "${APD_SIM_VIEW_MODE}"
  --apd_wrong_update_interval "${APD_WRONG_UPDATE_INTERVAL}"
  --apd_wrong_signal "${APD_WRONG_SIGNAL}"
  --apd_wrong_momentum "${APD_WRONG_MOMENTUM}"
  --apd_wrong_norm "${APD_WRONG_NORM}"
  --apd_expert_wrong_signal "${APD_EXPERT_WRONG_SIGNAL}"
  --apd_expert_wrong_momentum "${APD_EXPERT_WRONG_MOMENTUM}"
  --apd_reliability_mode "${APD_RELIABILITY_MODE}"
  --apd_gap_floor_mode "${APD_GAP_FLOOR_MODE}"
  --apd_gap_floor_mix "${APD_GAP_FLOOR_MIX}"
  --apd_source_prune_mode "${APD_SOURCE_PRUNE_MODE}"
  --apd_source_prune_floor "${APD_SOURCE_PRUNE_FLOOR}"
)

M3_COMMON_ARGS=(
  --apd_m3
  --apd_eval_final
  --apd_source_gate_diag
  --apd_beta "${APD_BETA}"
  --apd_ata_floor "${APD_ATA_FLOOR}"
  --apd_gate_score_mode "${APD_GATE_SCORE_MODE}"
  --apd_gate_source_sharpness "${APD_GATE_SOURCE_SHARPNESS}"
  --apd_gate_difficulty_weight "${APD_GATE_DIFFICULTY_WEIGHT}"
  --apd_gate_confidence_weight "${APD_GATE_CONFIDENCE_WEIGHT}"
  --apd_lambda_ata_anchor "${APD_LAMBDA_ATA_ANCHOR}"
  --apd_m3_start_epoch "${APD_M3_START_EPOCH}"
  --apd_lambda_m3 "${APD_LAMBDA_M3}"
  --apd_m3_source_temp "${APD_M3_SOURCE_TEMP}"
  --apd_m3_ata_temp "${APD_M3_ATA_TEMP}"
  --apd_gate_hidden "${APD_GATE_HIDDEN}"
  --apd_lambda_gate_prior "${APD_LAMBDA_GATE_PRIOR}"
  --apd_memory_update_mode "${APD_MEMORY_UPDATE_MODE}"
  --apd_wrong_event_mode "${APD_WRONG_EVENT_MODE}"
  --apd_memory_probe_weight "${APD_MEMORY_PROBE_WEIGHT}"
  --apd_wrong_probe_weight "${APD_WRONG_PROBE_WEIGHT}"
  --apd_ata_mass_target "${APD_ATA_MASS_TARGET}"
  --apd_lambda_ata_mass "${APD_LAMBDA_ATA_MASS}"
)

RUN_ARGS=("${COMMON_ARGS[@]}")
ENTRYPOINT="train_target_node_real.py"
GAMMA_TAG="none"

case "${GRAPHAPD_MODE}" in
  baseline)
    ENTRYPOINT="train_target_node.py"
    ;;
  m1)
    RUN_ARGS+=("${M1_ARGS[@]}")
    ;;
  m1_m2)
    RUN_ARGS+=("${M1_ARGS[@]}" "${M2_ARGS[@]}")
    ;;
  priorgate_ablation)
    RUN_ARGS+=(
      "${M1_ARGS[@]}" "${M2_ARGS[@]}" "${M3_COMMON_ARGS[@]}"
      --apd_m3_mode prior_gate
      --apd_m3_eval_only
      --apd_eval_blend_mode none
      --apd_eval_blend_gamma 0.0
    )
    GAMMA_TAG="0.00"
    ;;
  priorgate_joint)
    RUN_ARGS+=(
      "${M1_ARGS[@]}" "${M2_ARGS[@]}" "${M3_COMMON_ARGS[@]}"
      --apd_m3_mode prior_gate
      --apd_m3_use_clean_weight
      --apd_eval_blend_mode none
      --apd_eval_blend_gamma 0.0
    )
    GAMMA_TAG="joint-prior"
    ;;
  trainablegate_ablation)
    RUN_ARGS+=(
      "${M1_ARGS[@]}" "${M2_ARGS[@]}" "${M3_COMMON_ARGS[@]}"
      --apd_m3_mode trainable_gate
      --apd_trainable_gate
      --apd_eval_blend_mode none
      --apd_eval_blend_gamma 0.0
    )
    GAMMA_TAG="0.00"
    ;;
  full_joint)
    RUN_ARGS+=(
      "${M1_ARGS[@]}" "${M2_ARGS[@]}" "${M3_COMMON_ARGS[@]}"
      --apd_m3_mode trainable_gate
      --apd_trainable_gate
      --apd_m3_use_clean_weight
      --apd_eval_blend_mode none
      --apd_eval_blend_gamma 0.0
    )
    GAMMA_TAG="joint"
    ;;
esac

if [[ "${ENTRYPOINT}" == "train_target_node_real.py" ]]; then
  RUN_ARGS+=(--pretrain_dir "${PRETRAIN_DIR}")
fi

EXTRA_ARGS=()
if [[ -n "${APD_EXTRA_ARGS}" ]]; then
  EXTRA_ARGS=( ${APD_EXTRA_ARGS} )
fi

LOG_FILE=${LOG_FILE:-"${LOG_DIR}/${TARGET}_${GRAPHAPD_MODE}_seed${SEED}_g${GAMMA_TAG}_$(date +%Y%m%d_%H%M%S).log"}

echo "GRAPHAPD_MODE=${GRAPHAPD_MODE}"
echo "TARGET=${TARGET} SEED=${SEED} DEVICE=${DEVICE} EPOCHS=${EPOCHS}"
echo "ENTRYPOINT=${ENTRYPOINT}"
echo "LOG_FILE=${LOG_FILE}"

"${PYTHON}" "${ENTRYPOINT}" "${RUN_ARGS[@]}" "${EXTRA_ARGS[@]}" 2>&1 | tee "${LOG_FILE}"

echo "log=${LOG_FILE}"
grep -E 'APD_M1_SUMMARY|APD_M2_SUMMARY|APD_M3_SUMMARY|APD_SAFE_BLEND_SUMMARY|APD_SOURCE_GATE_DIAG|After adaptation|Best observed target accuracy' "${LOG_FILE}" || true
