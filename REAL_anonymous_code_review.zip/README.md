# REAL: Reliability-Aware Dynamic Expert Allocation

Anonymous code package for node classification on CSBM, Twitch, and Citation. This is an adapted snapshot of an earlier implementation. It has not yet been validated as reproducing the numerical results of the accompanying manuscript.

## Code layout

- `source_reliability.py`: structural perturbation for source-model reliability estimation (SPRE).
- `prediction_history.py`: prediction history modeling for target adaptation (PHTA).
- `expert_allocation.py`: reliability integration for dynamic expert allocation (RDEA).
- `train_target_node_real.py`: target training and evaluation.
- `configs/paper_common.env`: common configuration; target files contain the target and selected optimizer parameters.

Some internal `apd_*` options and `M1/M2/M3` identifiers remain for compatibility with the earlier implementation. They correspond to SPRE, PHTA, and RDEA respectively.

## Parameters

GCN, hidden dimension 128, two graph layers, five perturbed views, Adam, `lambda_sta=1`, `lambda_con=0.05`, five seeds (`2080 2090 2100 2110 2120`), 2000 epochs. Reliability is refreshed every five epochs. Target-specific learning rate and weight decay are drawn from the manuscript grid `{0.1, 0.01, 0.001, 0.0001}`. The previous code names for stable and conflicting supervision are `APD_LAMBDA_CLEAN` and `APD_LAMBDA_NOISE`.

## Setup and run

Use a compatible Python, PyTorch, and PyTorch Geometric environment. Place publicly available benchmark data in `data/` as expected by `datasets.py`.

```bash
CONFIG=configs/DE.env SEED=2080 DEVICE=cuda:0 bash scripts/run_graphapd_node.sh
```

The supplied `pretrain/` checkpoints come from the earlier archive. New runs are required before citing numerical reproduction with these updated parameters.

## Code provenance

This implementation derives in part from GraphATA (Zhang and He, WWW 2025). The supplied source archive contains no license file. Verify the upstream license and redistribution rights before publishing this package.
